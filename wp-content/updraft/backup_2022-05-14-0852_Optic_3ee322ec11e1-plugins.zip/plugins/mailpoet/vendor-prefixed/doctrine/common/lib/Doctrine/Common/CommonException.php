<?php
namespace MailPoetVendor\Doctrine\Common;
if (!defined('ABSPATH')) exit;
use Exception;
class CommonException extends Exception
{
}
