<?php
namespace MailPoetVendor\Doctrine\Persistence\Reflection;
if (!defined('ABSPATH')) exit;
class TypedNoDefaultRuntimePublicReflectionProperty extends RuntimePublicReflectionProperty
{
 use TypedNoDefaultReflectionPropertyBase;
}
