<?php
declare (strict_types=1);
namespace MailPoetVendor\Doctrine\ORM\Mapping;
if (!defined('ABSPATH')) exit;
final class SqlResultSetMappings implements Annotation
{
 public $value = [];
}
