<?php
declare (strict_types=1);
namespace MailPoetVendor\Doctrine\ORM\Proxy;
if (!defined('ABSPATH')) exit;
use MailPoetVendor\Doctrine\Common\Proxy\Proxy as BaseProxy;
interface Proxy extends BaseProxy
{
}
