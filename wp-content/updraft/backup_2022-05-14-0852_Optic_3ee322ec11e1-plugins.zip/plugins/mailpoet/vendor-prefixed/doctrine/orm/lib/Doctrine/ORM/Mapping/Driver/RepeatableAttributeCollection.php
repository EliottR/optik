<?php
declare (strict_types=1);
namespace MailPoetVendor\Doctrine\ORM\Mapping\Driver;
if (!defined('ABSPATH')) exit;
use ArrayObject;
use MailPoetVendor\Doctrine\ORM\Mapping\Annotation;
final class RepeatableAttributeCollection extends ArrayObject
{
}
