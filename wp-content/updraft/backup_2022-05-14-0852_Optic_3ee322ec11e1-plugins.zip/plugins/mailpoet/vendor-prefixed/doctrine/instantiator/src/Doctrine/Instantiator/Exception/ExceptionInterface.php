<?php
namespace MailPoetVendor\Doctrine\Instantiator\Exception;
if (!defined('ABSPATH')) exit;
use Throwable;
interface ExceptionInterface extends Throwable
{
}
