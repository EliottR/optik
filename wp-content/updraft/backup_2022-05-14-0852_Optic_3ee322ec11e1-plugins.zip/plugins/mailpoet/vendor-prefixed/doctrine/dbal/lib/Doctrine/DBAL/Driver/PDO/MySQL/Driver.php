<?php
namespace MailPoetVendor\Doctrine\DBAL\Driver\PDO\MySQL;
if (!defined('ABSPATH')) exit;
use MailPoetVendor\Doctrine\DBAL\Driver\PDOMySql;
final class Driver extends PDOMySql\Driver
{
}
