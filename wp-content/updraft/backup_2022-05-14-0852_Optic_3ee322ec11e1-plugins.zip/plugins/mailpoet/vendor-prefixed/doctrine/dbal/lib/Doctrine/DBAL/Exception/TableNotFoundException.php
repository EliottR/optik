<?php
namespace MailPoetVendor\Doctrine\DBAL\Exception;
if (!defined('ABSPATH')) exit;
class TableNotFoundException extends DatabaseObjectNotFoundException
{
}
