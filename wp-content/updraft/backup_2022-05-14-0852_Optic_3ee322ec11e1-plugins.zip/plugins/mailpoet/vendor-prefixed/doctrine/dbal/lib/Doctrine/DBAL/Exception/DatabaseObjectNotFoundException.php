<?php
namespace MailPoetVendor\Doctrine\DBAL\Exception;
if (!defined('ABSPATH')) exit;
class DatabaseObjectNotFoundException extends ServerException
{
}
