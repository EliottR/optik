<?php
namespace MailPoetVendor\Doctrine\DBAL\Driver\PDO\SQLSrv;
if (!defined('ABSPATH')) exit;
use MailPoetVendor\Doctrine\DBAL\Driver\PDOSqlsrv;
final class Connection extends PDOSqlsrv\Connection
{
}
