<?php
namespace MailPoetVendor\Doctrine\DBAL\Driver\PDO\OCI;
if (!defined('ABSPATH')) exit;
use MailPoetVendor\Doctrine\DBAL\Driver\PDOOracle;
final class Driver extends PDOOracle\Driver
{
}
