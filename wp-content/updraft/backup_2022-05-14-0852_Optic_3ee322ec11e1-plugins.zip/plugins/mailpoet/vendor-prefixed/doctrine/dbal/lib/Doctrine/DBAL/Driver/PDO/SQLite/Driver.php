<?php
namespace MailPoetVendor\Doctrine\DBAL\Driver\PDO\SQLite;
if (!defined('ABSPATH')) exit;
use MailPoetVendor\Doctrine\DBAL\Driver\PDOSqlite;
final class Driver extends PDOSqlite\Driver
{
}
