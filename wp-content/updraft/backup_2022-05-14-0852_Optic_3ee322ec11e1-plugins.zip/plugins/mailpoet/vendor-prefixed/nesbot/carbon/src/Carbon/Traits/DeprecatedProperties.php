<?php
declare (strict_types=1);
namespace MailPoetVendor\Carbon\Traits;
if (!defined('ABSPATH')) exit;
trait DeprecatedProperties
{
 public $localeDayOfWeek;
 public $shortLocaleDayOfWeek;
 public $localeMonth;
 public $shortLocaleMonth;
}
