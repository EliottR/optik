<?php
namespace MailPoetVendor\Carbon\Traits;
if (!defined('ABSPATH')) exit;
trait ObjectInitialisation
{
 protected $constructedObjectId;
}
